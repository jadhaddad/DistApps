package staff;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Set;

import hotel.BookingDetail;
import hotel.BookingManager;
import hotel.IBookingManager;
import hotel.Room;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class BookingClient extends AbstractScriptedSimpleTest implements Serializable {

	private IBookingManager bm = null;


	public static void main(String[] args) throws Exception {
		BookingClient client = new BookingClient();
		client.run();

	}

	/***************
	 * CONSTRUCTOR *
	 ***************/
	private String bookingName;

	public BookingClient() {
		try {
			//Look up the registered remote instance of the booking manager
			Registry registry = LocateRegistry.getRegistry();
			bm = (IBookingManager) registry.lookup("BookingManager");
		} catch (Exception exp) {
			exp.printStackTrace();
		}
		//
	}

	// Implement with exception thrown
	@Override
	public boolean isRoomAvailable(Integer roomNumber, LocalDate date) {
		try {
			return bm.isRoomAvailable(roomNumber, date);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

		@Override
		public void addBooking(BookingDetail bookingDetail) throws Exception {
			try {
				bm.addBooking(bookingDetail);
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		@Override
		public Set<Integer> getAvailableRooms(LocalDate date) {
			try {
				return bm.getAvailableRooms(date);
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}

		@Override
		public Set<Integer> getAllRooms() {
			try {
				return bm.getAllRooms();
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}

}
