package hotel;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class BookingMain {

    public static void main(String[] args) {
        try {
            // Create and export a remote object
            IBookingManager bm = new BookingManager();
            IBookingManager stub = (IBookingManager) UnicastRemoteObject.exportObject(bm, 0);

            // Start the RMI registry on port 1099
            Registry registry = LocateRegistry.createRegistry(1099);

            // Bind the remote object to the registry
            registry.rebind("BookingManager", stub);

            System.out.println("BookingManager server ready");
        } catch (Exception e) {
            System.err.println("BookingManager server exception:");
            e.printStackTrace();
        }
    }

}
