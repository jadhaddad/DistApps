package hotel;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class BookingManager implements IBookingManager{

	private Room[] rooms;

	public BookingManager() {
		this.rooms = initializeRooms();
	}



	public Set<Integer> getAllRooms() {
		Set<Integer> allRooms = new HashSet<Integer>();
		Iterable<Room> roomIterator = Arrays.asList(rooms);
		for (Room room : roomIterator) {
			allRooms.add(room.getRoomNumber());
		}
		return allRooms;
	}

	public Room getRoom(Integer roomNumber) {
		Iterable<Room> roomIterator = Arrays.asList(rooms);
		for (Room room : roomIterator) {
			if (room.getRoomNumber().equals(roomNumber)) {
				return room;
			}
		}
		return null;
	}

	public boolean isRoomAvailable(Integer roomNumber, LocalDate date) {
		//Loop through all rooms and check if the specified room with given number is available
		//on the given date
		Iterable<Room> roomIterator = Arrays.asList(rooms);
		for (Room room : roomIterator) {
			if (room.getRoomNumber().equals(roomNumber)) {
				List<BookingDetail> bookings = room.getBookings();
				for (BookingDetail booking : bookings) {
					LocalDate startDate = booking.getDate();
					LocalDate endDate = startDate.plusDays(1); // assume one-day bookings
					if (date.isEqual(startDate) || (date.isAfter(startDate) && date.isBefore(endDate))) {
						// There is a booking that overlaps with the given date
						return false;
					}
				}
				// There is no booking that overlaps with the given date
				return true;
			}
		}
		// The given room number is not valid
		return false;

	}

	public void addBooking(BookingDetail bookingDetail) {
//		Iterable<Room> roomIterator = Arrays.asList(rooms);
//		for (Room room : roomIterator) {
//			if (room.getRoomNumber().equals(bookingDetail.getRoomNumber())) {
//				room.getBookings().add(bookingDetail);
//			}
//			// else throw an exception
//			else {
//				throw new IllegalArgumentException("Room is not available");
//			}
//		}
		Room room = null;
		for (Room r : rooms) {
			if (r.getRoomNumber().equals(bookingDetail.getRoomNumber())) {
				room = r;
				break;
			}
		}
		if (room == null) {

		}
		for (BookingDetail b : room.getBookings()) {
			if (b.getDate().equals(bookingDetail.getDate())) {

			}
		}
		room.getBookings().add(bookingDetail);

	}
	public Set<Integer> getAvailableRooms(LocalDate date) {
		Iterable<Room> roomIterator = Arrays.asList(rooms);
		Set<Integer> availableRooms = new HashSet<Integer>();
		for (Room room : roomIterator) {
			if (isRoomAvailable(room.getRoomNumber(), date)) {
				availableRooms.add(room.getRoomNumber());
			}
		}
		return availableRooms;
	}

	private static Room[] initializeRooms() {
		Room[] rooms = new Room[4];
		rooms[0] = new Room(101);
		rooms[1] = new Room(102);
		rooms[2] = new Room(201);
		rooms[3] = new Room(203);
		return rooms;
	}


}
