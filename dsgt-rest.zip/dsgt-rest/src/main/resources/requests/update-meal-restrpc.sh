curl -X PUT localhost:8080/restrpc/meals/cfd1601f-29a0-485d-8d21-7607ec0340c8 -H 'Content-type:application/json' -d @update-meal.json -v

