package be.kuleuven.foodrestservice.domain;

import java.util.ArrayList;
import java.util.List;

public class mealOrder {

    private String orderId;
    private String address;
    private List<String> mealIds = new ArrayList<>();


    public mealOrder() {}

    public mealOrder(String orderId,String address, List<String> mealId) {
        this.orderId = orderId;
        this.address = address;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String id) {
        this.orderId = id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public List<String> getMealIds() {
        return mealIds;
    }

    public void addMealId(String mealId) {
        mealIds.add(mealId);
    }
}
