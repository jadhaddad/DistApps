package be.kuleuven.foodrestservice.controllers;

import be.kuleuven.foodrestservice.domain.Meal;
import be.kuleuven.foodrestservice.domain.MealsRepository;
import be.kuleuven.foodrestservice.domain.mealOrder;
import be.kuleuven.foodrestservice.exceptions.MealNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.swing.text.html.parser.Entity;
import java.util.*;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
public class MealsRestController {

    private final MealsRepository mealsRepository;

    @Autowired
    MealsRestController(MealsRepository mealsRepository) {
        this.mealsRepository = mealsRepository;
    }

    @GetMapping("/rest/meals/{id}")
    EntityModel<Meal> getMealById(@PathVariable String id) {
        Meal meal = mealsRepository.findMeal(id).orElseThrow(() -> new MealNotFoundException(id));

        return mealToEntityModel(id, meal);
    }

    @GetMapping("/rest/meals/largest")
    EntityModel<Meal> getMealLargest(){
        Meal meal = mealsRepository.getMealLargest().orElseThrow(() -> new MealNotFoundException("largest"));

        return mealToEntityModel(meal.getId(),meal);
    }

    @GetMapping("/rest/meals/cheapest")
    EntityModel<Meal>  getMealCheapest(){
        Meal meal = mealsRepository.getMealCheapest().orElseThrow(() -> new MealNotFoundException("cheapest"));

        return mealToEntityModel(meal.getId(),meal);
    }

    @GetMapping("/rest/meals")
    CollectionModel<EntityModel<Meal>> getMeals() {
        Collection<Meal> meals = mealsRepository.getAllMeal();

        List<EntityModel<Meal>> mealEntityModels = new ArrayList<>();
        for (Meal m : meals) {
            EntityModel<Meal> em = mealToEntityModel(m.getId(), m);
            mealEntityModels.add(em);
        }
        return CollectionModel.of(mealEntityModels,
                linkTo(methodOn(MealsRestController.class).getMeals()).withSelfRel());
    }

    @PostMapping("/rest/meals")
    @ResponseStatus(HttpStatus.CREATED)
    public Meal addMeal(@RequestBody Meal meal) {
        mealsRepository.addMeal(meal);
        return meal;
    }

    @PutMapping("/rest/meals/{id}")
    public Meal updateMeal(@PathVariable String id, @RequestBody Meal meal) {
        Optional<Meal> existingMeal = mealsRepository.findMeal(id);
        if (existingMeal.isPresent()) {
            Meal updatedMeal = existingMeal.get();
            updatedMeal.setName(meal.getName());
            updatedMeal.setDescription(meal.getDescription());
            updatedMeal.setMealType(meal.getMealType());
            updatedMeal.setKcal(meal.getKcal());
            updatedMeal.setPrice(meal.getPrice());

            mealsRepository.updateMeal(updatedMeal);
            return updatedMeal;
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Meal not found");
        }
    }

    @DeleteMapping("/rest/meals/{id}")
    public void deleteMeal(@PathVariable String id) {
        Optional<Meal> existingMeal = mealsRepository.findMeal(id);
        if (existingMeal.isPresent()) {
            mealsRepository.deleteMeal(id);
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Meal not found");
        }
    }

    @GetMapping("/rest/order/{orderId}")
    EntityModel<mealOrder> getOrderById(@PathVariable String orderId){
        mealOrder order = mealsRepository.findOrderById(orderId).orElseThrow(() -> new MealNotFoundException(orderId));

        return mealOrderToEntityModel(orderId, order);
    }




    @PostMapping("/rest/order")
    @ResponseStatus(HttpStatus.CREATED)
    public mealOrder addMealOrder(@RequestBody mealOrder order) {
        mealsRepository.addOrder(order);
        return order;
    }

    private EntityModel<Meal> mealToEntityModel(String id, Meal meal) {
        return EntityModel.of(meal,
                linkTo(methodOn(MealsRestController.class).getMealById(id)).withSelfRel(),
                linkTo(methodOn(MealsRestController.class).getMeals()).withRel("rest/meals"));
    }

    private EntityModel<mealOrder> mealOrderToEntityModel(String id, mealOrder order) {
        return EntityModel.of(order,
                linkTo(methodOn(MealsRestController.class).getOrderById(id)).withSelfRel(),
                linkTo(methodOn(MealsRestController.class).getMeals()).withRel("rest/order"));
    }

}
