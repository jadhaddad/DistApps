package be.kuleuven.foodrestservice.domain;

import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.annotation.PostConstruct;
import java.util.*;

@Component
public class MealsRepository {
    // map: id -> meal
    private static final Map<String, Meal> meals = new HashMap<>();
    private static final Map<String, mealOrder> orders = new HashMap<>();

    @PostConstruct
    public void initData() {

        Meal a = new Meal();
        a.setId("5268203c-de76-4921-a3e3-439db69c462a");
        a.setName("Steak");
        a.setDescription("Steak with fries");
        a.setMealType(MealType.MEAT);
        a.setKcal(1100);
        a.setPrice((10.00));

        meals.put(a.getId(), a);

        Meal b = new Meal();
        b.setId("4237681a-441f-47fc-a747-8e0169bacea1");
        b.setName("Portobello");
        b.setDescription("Portobello Mushroom Burger");
        b.setMealType(MealType.VEGAN);
        b.setKcal(637);
        b.setPrice((7.00));

        meals.put(b.getId(), b);

        Meal c = new Meal();
        c.setId("cfd1601f-29a0-485d-8d21-7607ec0340c8");
        c.setName("Fish and Chips");
        c.setDescription("Fried fish with chips");
        c.setMealType(MealType.FISH);
        c.setKcal(950);
        c.setPrice(5.00);

        mealOrder d = new mealOrder();
        d.setOrderId("1234");
        d.setAddress("Andreas Vesaliuslaan 145");
        d.addMealId(c.getId());
        d.addMealId(b.getId());


        meals.put(c.getId(), c);

        orders.put(d.getOrderId(), d);
    }

    public Optional<Meal> findMeal(String id) {
        Assert.notNull(id, "The meal id must not be null");
        Meal meal = meals.get(id);
        return Optional.ofNullable(meal);
    }

    private Meal getLargestMeal() {
        Meal largestMeal = null;
        for (Meal meal : meals.values()) {
            if (largestMeal == null || meal.getKcal() > largestMeal.getKcal()) {
                largestMeal = meal;
            }
        }
        return largestMeal;
    }

    public Optional<Meal> getMealLargest() {
        Meal largestMeal = getLargestMeal();
        return Optional.ofNullable(largestMeal);
    }

    private Meal getCheapestMeal() {
        Meal cheapestMeal = null;
        for (Meal meal : meals.values()) {
            if (cheapestMeal == null || meal.getPrice() < cheapestMeal.getPrice()) {
                cheapestMeal = meal;
            }
        }
        return cheapestMeal;
    }

    public Optional<Meal> getMealCheapest() {
        Meal cheapestMeal = getCheapestMeal();
        return Optional.ofNullable(cheapestMeal);
    }

    public void addMeal(Meal meal) {
        Assert.notNull(meal, "The meal must not be null");
        meals.put(meal.getId(), meal);
    }

    public void updateMeal(Meal updatedMeal) {
        Assert.notNull(updatedMeal.getId(), "The meal id must not be null");
        Assert.notNull(updatedMeal, "The updated meal must not be null");

        Meal meal = meals.get(updatedMeal.getId());
        if (meal != null) {
            meal.setName(updatedMeal.getName());
            meal.setDescription(updatedMeal.getDescription());
            meal.setMealType(updatedMeal.getMealType());
            meal.setKcal(updatedMeal.getKcal());
            meal.setPrice(updatedMeal.getPrice());
        } else {
            throw new IllegalArgumentException("Meal not found with id: " + updatedMeal.getId());
        }
    }

    public void deleteMeal(String id) {
        Assert.notNull(id, "The meal id must not be null");

        Meal meal = meals.get(id);
        if (meal != null) {
            meals.remove(id);
        } else {
            throw new IllegalArgumentException("Meal not found with id: " + id);
        }
    }

    public void addOrder(mealOrder order){
        Assert.notNull(order, "The meal must not be null");
        orders.put(order.getOrderId(), order);
    }

    public Optional<mealOrder> findOrderById(String orderId){
        Assert.notNull(orderId, "The meal id must not be null");
        mealOrder order = orders.get(orderId);
        return Optional.ofNullable(order);
    }

    public Collection<Meal> getAllMeal() {
        return meals.values();
    }
}
