package be.kuleuven.foodrestservice.controllers;

import be.kuleuven.foodrestservice.domain.Meal;
import be.kuleuven.foodrestservice.domain.MealsRepository;
import be.kuleuven.foodrestservice.domain.mealOrder;
import be.kuleuven.foodrestservice.exceptions.MealNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Collection;
import java.util.Optional;

@RestController
public class MealsRestRpcStyleController {

    private final MealsRepository mealsRepository;

    @Autowired
    MealsRestRpcStyleController(MealsRepository mealsRepository) {
        this.mealsRepository = mealsRepository;
    }

    @GetMapping("/restrpc/meals/{id}")
    Meal getMealById(@PathVariable String id) {
        Optional<Meal> meal = mealsRepository.findMeal(id);

        return meal.orElseThrow(() -> new MealNotFoundException(id));
    }

    @PostMapping("/restrpc/meals")
    @ResponseStatus(HttpStatus.CREATED)
    public Meal addMeal(@RequestBody Meal meal) {
        mealsRepository.addMeal(meal);
        return meal;
    }

    @PutMapping("/restrpc/meals/{id}")
    public Meal updateMeal(@PathVariable String id, @RequestBody Meal meal) {
        Optional<Meal> existingMeal = mealsRepository.findMeal(id);
        if (existingMeal.isPresent()) {
            Meal updatedMeal = existingMeal.get();
            updatedMeal.setName(meal.getName());
            updatedMeal.setDescription(meal.getDescription());
            updatedMeal.setMealType(meal.getMealType());
            updatedMeal.setKcal(meal.getKcal());
            updatedMeal.setPrice(meal.getPrice());

            mealsRepository.updateMeal(updatedMeal);
            return updatedMeal;
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Meal not found");
        }
    }

    @DeleteMapping("/restrpc/meals/{id}")
    public void deleteMeal(@PathVariable String id) {
        Optional<Meal> existingMeal = mealsRepository.findMeal(id);
        if (existingMeal.isPresent()) {
            mealsRepository.deleteMeal(id);
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Meal not found");
        }
    }

    @PostMapping("restrpc/order")
    public ResponseEntity<String> orderMeals(@RequestBody mealOrder mealOrder) {
        StringBuilder responseBuilder = new StringBuilder();

        for (String mealId : mealOrder.getMealIds()) {
            Optional<Meal> optionalMeal = mealsRepository.findMeal(mealId);
            if (optionalMeal.isPresent()) {
                Meal meal = optionalMeal.get();
                responseBuilder.append("Ordered meal: ").append(meal.getName()).append("\n");
            } else {
                responseBuilder.append("Meal not found: ").append(mealId).append("\n");
            }
        }

        responseBuilder.append("Delivery address: ").append(mealOrder.getAddress()).append("\n");

        return ResponseEntity.ok(responseBuilder.toString());
    }

    @GetMapping("/restrpc/meals")
    Collection<Meal> getMeals() {
        return mealsRepository.getAllMeal();
    }

    @GetMapping("/restrpc/meals/largest")
    Meal getMealLargest(){
        Optional<Meal> meal = mealsRepository.getMealLargest();

        return meal.orElseThrow(() -> new MealNotFoundException("largest"));
    }

    @GetMapping("/restrpc/meals/cheapest")
    Meal getMealCheapest(){
        Optional<Meal> meal = mealsRepository.getMealCheapest();

        return meal.orElseThrow(() -> new MealNotFoundException("cheapest"));
    }
}
