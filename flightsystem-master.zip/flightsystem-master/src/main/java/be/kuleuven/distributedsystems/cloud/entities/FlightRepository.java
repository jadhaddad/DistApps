package be.kuleuven.distributedsystems.cloud.entities;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.ArrayList;
import java.util.List;


import static org.springframework.util.Assert.notNull;

@Component
public class FlightRepository {
    private static final Map<String, Flight> flights = new HashMap<>();
    private static final Map<String, Seat> seats = new HashMap<>();

    // I want to read the flights from the data.json file
//    @PostConstruct
//    public void initData() throws IOException {
//        ObjectMapper mapper = new ObjectMapper();
//
//        // Load the data from the JSON file
//        InputStream inputStream = getClass().getResourceAsStream("/data.json");
//        List<Flight> flightList = mapper.readValue(inputStream, new TypeReference<List<Flight>>(){});
//
//        // Populate the flights map with the data
//        for (Flight flight : flightList) {
//            flights.put(flight.getName(), flight);
//        }
//    }

    private static final String API_KEY = "Iw8zeveVyaPNWonPNaU0213uw3g6Ei";
    private static final String RELIABLE_AIRLINE_BASE_URL = "http://reliable.westeurope.cloudapp.azure.com";
    private static final String UNRELIABLE_AIRLINE_BASE_URL = "http://unreliable.eastus.cloudapp.azure.com";



    public static Collection<Flight> getAllFlights() {
        List<Flight> flights = new ArrayList<>();



        try {
            //URL url = new URL(API_BASE_URL + "/flights?key=" + API_KEY);
            URL url = new URL("http://unreliable.eastus.cloudapp.azure.com/flights?key=Iw8zeveVyaPNWonPNaU0213uw3g6Ei");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();

            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                ObjectMapper objectMapper = new ObjectMapper();
                flights = objectMapper.readValue(connection.getInputStream(),
                        objectMapper.getTypeFactory().constructCollectionType(List.class, Flight.class));
            }
            connection.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return flights;
    }

    public static Flight findFlight(String airline, UUID flightId) {
        Assert.notNull(airline, "airlineId must not be null");
        Assert.notNull(flightId, "flightId must not be null");
        return flights.get(airline + flightId);
    }

    // TODO: Implement this method to find flight time (from the Seat class) without creating extra functions
    public static ArrayList<String> findFlightTimeOfFlight(String airline, UUID flightId) {
        Assert.notNull(airline, "airlineId must not be null");
        Assert.notNull(flightId, "flightId must not be null");
        ArrayList<LocalDateTime> flightTimes = new ArrayList<>();

        //There is a place where you can just see all the times i.e http://unreliable.eastus.cloudapp.azure.com/flights/986195e5-2b53-42c1-aab4-e621cbc0e522/times?key=Iw8zeveVyaPNWonPNaU0213uw3g6Ei



        Collections.sort(flightTimes, new Comparator<LocalDateTime>() {
            @Override
            public int compare(LocalDateTime time1, LocalDateTime time2) {
                return time1.compareTo(time2);
            }
        });

        ArrayList<String> flightTimesAsString = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        for (LocalDateTime time : flightTimes) {
            String timeString = time.format(formatter);
            flightTimesAsString.add(timeString);
        }

        return flightTimesAsString;
    }



}
