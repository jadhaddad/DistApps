package be.kuleuven.distributedsystems.cloud.controller;

import be.kuleuven.distributedsystems.cloud.entities.*;
import be.kuleuven.distributedsystems.cloud.auth.*;
import com.google.api.Http;
import com.google.api.core.ApiFuture;
import com.google.cloud.Timestamp;
import com.google.cloud.firestore.*;
import org.apache.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.checkerframework.framework.qual.DefaultQualifier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.hateoas.CollectionModel;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;


import javax.annotation.Resource;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;
import java.time.LocalDateTime;
@RestController
@RequestMapping("/api")
public class APIController {

    private static final String API_KEY = "Iw8zeveVyaPNWonPNaU0213uw3g6Ei";
    private static final int MAX_ATTEMPTS = 5;
    private static final long RETRY_DELAY = 1000;
    WebClient.Builder webClientBuilder;

    List<Booking> bookings = new ArrayList<>();
    List<User> users = new ArrayList<>();

    @Autowired
    private Firestore db;

    @Autowired
    public APIController(WebClient.Builder webClientBuilder) {
        this.webClientBuilder = webClientBuilder;
    }

    private <T> T makeRequest(RequestFunction<T> requestFunction) {
        for (int attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
            try {
                return requestFunction.execute();
            } catch (WebClientResponseException ex) {
                if (attempt < MAX_ATTEMPTS - 1) {
                    try {
                        Thread.sleep(RETRY_DELAY);
                    } catch (InterruptedException ignored) {
                    }
                }
            }
        }
        return null;
    }

    @GetMapping("/getFlights")
    public List<Flight> getFlights() {
        List<Flight> flights = new ArrayList<>();

        // Request flights from Reliable Airline
        List<Flight> reliableFlights = makeRequest(() -> webClientBuilder
                .baseUrl("http://reliable.westeurope.cloudapp.azure.com/")
                .build()
                .get()
                .uri(uriBuilder -> uriBuilder
                        .pathSegment("flights")
                        .queryParam("key", API_KEY)
                        .build())
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<CollectionModel<Flight>>() {})
                .block()
                .getContent()
                .stream()
                .toList());

        // Request flights from Unreliable Airline
        List<Flight> unreliableFlights = makeRequest(() -> webClientBuilder
                .baseUrl("http://unreliable.eastus.cloudapp.azure.com/")
                .build()
                .get()
                .uri(uriBuilder -> uriBuilder
                        .pathSegment("flights")
                        .queryParam("key", API_KEY)
                        .build())
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<CollectionModel<Flight>>() {})
                .block()
                .getContent()
                .stream()
                .toList());

        flights.addAll(reliableFlights);
        flights.addAll(unreliableFlights);

        return flights != null ? flights.stream().toList() : new ArrayList<>();
    }
        @GetMapping("/getFlight")
        public Flight getFlightById(@RequestParam String airline, @RequestParam UUID flightId) {
            var flight = makeRequest(() -> this.webClientBuilder
                    .baseUrl(airline)
                    .build()
                    .get()
                    .uri(uriBuilder -> uriBuilder
                            .pathSegment("flights")
                            .pathSegment(flightId.toString())
                            .queryParam("key", API_KEY)
                            .build())
                    .retrieve()
                    .bodyToMono(Flight.class)
                    .block());

            return flight;
        }

        @GetMapping("/getFlightTimes")
        public List<String> getTimeById(@RequestParam String airline, @RequestParam UUID flightId) {
            var time = makeRequest(() -> this.webClientBuilder
                    .baseUrl(airline)
                    .build()
                    .get()
                    .uri(uriBuilder -> uriBuilder
                            .pathSegment("flights")
                            .pathSegment(flightId.toString())
                            .pathSegment("times")
                            .queryParam("key", API_KEY)
                            .build())
                    .retrieve()
                    .bodyToMono(new ParameterizedTypeReference<CollectionModel<String>>() {})
                    .block()
                    .getContent());

            List<String> flightTimes = new ArrayList<>(time);
            Collections.sort(flightTimes);
            return flightTimes;
        }

        @GetMapping("/getSeat")
        public Seat getSeatById(
                @RequestParam String airline,
                @RequestParam UUID flightId,
                @RequestParam String seatId
        ) {
            var seat = makeRequest(() -> this.webClientBuilder
                    .baseUrl(airline)
                    .build()
                    .get()
                    .uri(uriBuilder -> uriBuilder
                            .pathSegment("flights")
                            .pathSegment(flightId.toString())
                            .pathSegment("seats")
                            .pathSegment(seatId)
                            .queryParam("key", API_KEY)
                            .build())
                    .retrieve()
                    .bodyToMono(Seat.class)
                    .block());

            return seat;
        }

        @GetMapping("/getAvailableSeats")
        public Map<String, List<Seat>> getAvailableSeats(
                @RequestParam String airline,
                @RequestParam UUID flightId,
                @RequestParam String time
        ) {
            var seats = makeRequest(() -> this.webClientBuilder
                    .baseUrl(airline)
                    .build()
                    .get()
                    .uri(uriBuilder -> uriBuilder
                            .pathSegment("flights")
                            .pathSegment(flightId.toString())
                            .pathSegment("seats")
                            .queryParam("key", API_KEY)
                            .queryParam("available", "true")
                            .queryParam("time", time)
                            .build())
                    .retrieve()
                    .bodyToMono(new ParameterizedTypeReference<CollectionModel<Seat>>() {})
                    .block()
                    .getContent());

            List<String> sortingOrder = List.of("First", "Business", "Economy");
            Map<String, List<Seat>> availableSeatsByClass = new HashMap<>();

            for (String type : sortingOrder) {
                List<Seat> availableSeats = seats.stream()
                        .filter(seat -> seat.getName() != null && seat.getType().equals(type))
                        .sorted(Comparator.comparingInt(seat -> parseSeatNumber(seat.getName())))
                        .toList();
                availableSeatsByClass.put(type, availableSeats);
            }

            return availableSeatsByClass;
        }
    private void addUser(User user) {
        boolean userExists = users.stream()
                .anyMatch(existingUser -> existingUser.getEmail().equals(user.getEmail()));

        if (!userExists) {
            users.add(user);
        }
    }
    public void addBooking(Booking booking) throws ExecutionException, InterruptedException {
        ApiFuture<WriteResult> result = db.collection("bookings").document(booking.getId().toString()).set(booking);
        System.out.println("Update time: " + result.get().getUpdateTime());
    }
    @PostMapping("/confirmQuotes")
    public void confirmQuotes(@RequestBody Quote[] quotes){
        User user = WebSecurityConfig.getUser();
        addUser(user);
        Booking booking = new Booking(UUID.randomUUID(), LocalDateTime.now(), user.getEmail());
        int cancelled = 0;

        for(Quote quote: quotes){
            if(cancelled == 0) {

                Ticket ticket = bookSeat(quote, user, booking);
                if (ticket == null) {
                    cancelTickets(booking);
                    cancelled = 1;
                } else {
                    booking.addTicket(ticket);
                    System.out.println("The ticket you are booking is " + ticket.getTicketId());
                }
            }
        }

        if(cancelled == 0) {
            try {
                addBooking(booking); // add booking to firestore
            } catch (ExecutionException | InterruptedException e) {
                e.printStackTrace();
                System.out.println("Exception message: " + e.getMessage());

            }}
    }
    public Ticket bookSeat(Quote quote, User user, Booking booking){
        for(int attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
            try {
                return this.webClientBuilder
                        .baseUrl(quote.getAirline())
                        .build()
                        .put()
                        .uri(uriBuilder -> uriBuilder
                                .pathSegment("flights")
                                .pathSegment(quote.getFlightId().toString())
                                .pathSegment("seats")
                                .pathSegment(quote.getSeatId().toString())
                                .pathSegment("ticket")
                                .queryParam("customer", user.getEmail())
                                .queryParam("bookingReference", booking.getId())
                                .queryParam("key", API_KEY)
                                .build())
                        .retrieve()
                        .bodyToMono(Ticket.class)
                        .block();
            } catch (WebClientResponseException ex) {

                if (ex.getRawStatusCode() == HttpStatus.SC_CONFLICT) {
                    System.out.println("Conflict encountered when booking seat with ID: " + quote.getSeatId());
                }
            }
        }
        return null;
    }

    public void cancelTickets(Booking booking){
        for(Ticket ticket: booking.getTickets()){
            this.webClientBuilder
                    .baseUrl(ticket.getAirline())
                    .build()
                    .delete()
                    .uri(uriBuilder -> uriBuilder
                            .pathSegment("flights")
                            .pathSegment(ticket.getFlightId().toString())
                            .pathSegment("seats")
                            .pathSegment(ticket.getSeatId().toString())
                            .pathSegment("ticket")
                            .pathSegment(ticket.getTicketId().toString())
                            .queryParam("key", API_KEY)
                            .build())
                    .retrieve()
                    .bodyToMono(Ticket.class)
                    .block();

            System.out.println("Ticket " + ticket.getSeatId() + " has been cancelled");
        }
    }

    // Get all bookings for a user
    private UUID getUUIDFromBits(Map<String, Object> dataMap, String key) {
        Map<String, Object> uuidMap = (Map<String, Object>) dataMap.get(key);
        if (uuidMap != null) {
            long mostSignificantBits = Long.parseLong(uuidMap.get("mostSignificantBits").toString());
            long leastSignificantBits = Long.parseLong(uuidMap.get("leastSignificantBits").toString());
            return new UUID(mostSignificantBits, leastSignificantBits);
        } else {
            return null;
        }
    }
    @GetMapping("/getBookings")
    public List<Booking> getBookings() throws ExecutionException, InterruptedException {
        User user = WebSecurityConfig.getUser();
        String userEmail = user.getEmail();
        System.out.println("UserEmail is " + userEmail);

        // Fetch Firestore
        ApiFuture<QuerySnapshot> querySnapshotApiFuture = db.collection("bookings").get();

        // Iterate over bookings
        List<Booking> bookingUser = new ArrayList<>();
        for (DocumentSnapshot documentSnapshot : querySnapshotApiFuture.get().getDocuments()) {
            Map<String, Object> bookingData = documentSnapshot.getData();
            if (bookingData != null && bookingData.get("customer") != null && bookingData.get("customer").equals(userEmail)) {
                UUID id = getUUIDFromBits(bookingData, "id");

                @SuppressWarnings("unchecked")
                Map<String, Object> timeMap = (Map<String, Object>) bookingData.get("time");
                LocalDateTime time = LocalDateTime.of(
                        ((Long) timeMap.get("year")).intValue(),
                        ((Long) timeMap.get("monthValue")).intValue(),
                        ((Long) timeMap.get("dayOfMonth")).intValue(),
                        ((Long) timeMap.get("hour")).intValue(),
                        ((Long) timeMap.get("minute")).intValue(),
                        ((Long) timeMap.get("second")).intValue(),
                        ((Long) timeMap.get("nano")).intValue());

                String customer = (String) bookingData.get("customer");

                List<Ticket> tickets = new ArrayList<>();
                List<Map<String, Object>> ticketDataList = (List<Map<String, Object>>) bookingData.get("tickets");
                if (ticketDataList != null) {
                    for (Map<String, Object> ticketData : ticketDataList) {
                        String airline = (String) ticketData.get("airline");
                        System.out.println("Airline is " + airline);
                        UUID flightId = getUUIDFromBits(ticketData, "flightId");
                        UUID seatId = getUUIDFromBits(ticketData, "seatId");
                        UUID ticketId = getUUIDFromBits(ticketData, "ticketId");
                        String bookingReference = (String) ticketData.get("bookingReference");
                        Ticket ticket = new Ticket(airline, flightId, seatId, ticketId, customer, bookingReference);
                        tickets.add(ticket);
                    }
                }

                if (id != null && time != null && tickets != null) {
                    Booking booking = new Booking(id, time, tickets, customer);
                    bookingUser.add(booking);
                }
            }
        }

        return bookingUser;
    }

    @GetMapping("/getAllBookings")
    public List<Booking> getAllBookings() throws ExecutionException, InterruptedException {
        // Fetch Firestore
        ApiFuture<QuerySnapshot> querySnapshotApiFuture = db.collection("bookings").get();

        List<Booking> allBookings = new ArrayList<>();
        for (DocumentSnapshot documentSnapshot : querySnapshotApiFuture.get().getDocuments()) {
            Map<String, Object> bookingData = documentSnapshot.getData();
            if (bookingData != null) {
                UUID id = getUUIDFromBits(bookingData, "id");

                @SuppressWarnings("unchecked")
                Map<String, Object> timeMap = (Map<String, Object>) bookingData.get("time");

                if (timeMap != null) {
                    LocalDateTime time = LocalDateTime.of(
                            ((Long) timeMap.get("year")).intValue(),
                            ((Long) timeMap.get("monthValue")).intValue(),
                            ((Long) timeMap.get("dayOfMonth")).intValue(),
                            ((Long) timeMap.get("hour")).intValue(),
                            ((Long) timeMap.get("minute")).intValue(),
                            ((Long) timeMap.get("second")).intValue(),
                            ((Long) timeMap.get("nano")).intValue());

                    String customer = (String) bookingData.get("customer");

                    List<Ticket> tickets = new ArrayList<>();
                    List<Map<String, Object>> ticketDataList = (List<Map<String, Object>>) bookingData.get("tickets");
                    if (ticketDataList != null) {
                        for (Map<String, Object> ticketData : ticketDataList) {
                            String airline = (String) ticketData.get("airline");
                            System.out.println("Airline is " + airline);
                            UUID flightId = getUUIDFromBits(ticketData, "flightId");
                            UUID seatId = getUUIDFromBits(ticketData, "seatId");
                            UUID ticketId = getUUIDFromBits(ticketData, "ticketId");
                            String bookingReference = (String) ticketData.get("bookingReference");
                            Ticket ticket = new Ticket(airline, flightId, seatId, ticketId, customer, bookingReference);
                            tickets.add(ticket);
                        }
                    }

                    if (id != null && time != null && tickets != null) {
                        Booking booking = new Booking(id, time, tickets, customer);
                        allBookings.add(booking);
                    }
                }
            }
        }

        return allBookings;
    }
    @GetMapping("/getBestCustomers")
    public List<String> getBestCustomers() throws ExecutionException, InterruptedException {
        // Fetch Firestore
        ApiFuture<QuerySnapshot> querySnapshotApiFuture = db.collection("bookings").get();

        // Map to store the number of tickets for each customer
        Map<String, Integer> customerTicketCount = new HashMap<>();

        // Iterate over bookings
        for (DocumentSnapshot documentSnapshot : querySnapshotApiFuture.get().getDocuments()) {
            Map<String, Object> bookingData = documentSnapshot.getData();
            if (bookingData != null) {
                String customer = (String) bookingData.get("customer");

                // Increment the ticket count for the customer
                customerTicketCount.put(customer, customerTicketCount.getOrDefault(customer, 0) + 1);
            }
        }

        // Find the maximum ticket count
        int maxTicketCount = 0;
        for (int ticketCount : customerTicketCount.values()) {
            if (ticketCount > maxTicketCount) {
                maxTicketCount = ticketCount;
            }
        }

        // Find the customers with the maximum ticket count
        List<String> bestCustomers = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : customerTicketCount.entrySet()) {
            if (entry.getValue() == maxTicketCount) {
                bestCustomers.add(entry.getKey());
            }
        }

        return bestCustomers;
    }

        private int parseSeatNumber(String seatName) {
            // Assuming seatName follows the pattern of numeric part followed by a letter part (e.g., 1A, 2B, 10A)
            int numericPart = Integer.parseInt(seatName.substring(0, seatName.length() - 1));
            char letterPart = seatName.charAt(seatName.length() - 1);
            return numericPart * 26 + (letterPart - 'A');
        }
    interface RequestFunction<T> {
        T execute();
    }
}



