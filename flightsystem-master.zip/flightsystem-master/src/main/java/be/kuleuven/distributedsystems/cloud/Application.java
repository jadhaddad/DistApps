package be.kuleuven.distributedsystems.cloud;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.FirestoreOptions;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.cloud.FirestoreClient;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.hateoas.config.EnableHypermediaSupport;
import org.springframework.hateoas.config.HypermediaWebClientConfigurer;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.security.web.firewall.DefaultHttpFirewall;
import org.springframework.security.web.firewall.HttpFirewall;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

@EnableHypermediaSupport(type = EnableHypermediaSupport.HypermediaType.HAL)
@SpringBootApplication
public class Application {
    @Bean
    public Firestore db(){
        return FirestoreOptions.getDefaultInstance()
                .toBuilder()
                .setProjectId(this.projectId())
                .build()
                .getService();
    }

    public static void main(String[] args) throws IOException {
        System.setProperty("server.port", System.getenv().getOrDefault("PORT", "8080"));

        ApplicationContext context = SpringApplication.run(Application.class, args);

        // TODO: (level 2) load this data into Firestore
        String data = new String(new ClassPathResource("data.json").getInputStream().readAllBytes());
    }

    @Bean
    public boolean isProduction() {
        return Objects.equals(System.getenv("GAE_ENV"), "standard");
    }

    @Bean
    public String projectId() {
        return "flightsystem-387809";
    }

    /*
     * You can use this builder to create a Spring WebClient instance which can be used to make REST-calls.
     */
    @Bean
    WebClient.Builder webClientBuilder(HypermediaWebClientConfigurer configurer) {
        return configurer.registerHypermediaTypes(WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(HttpClient.create()))
                .codecs(clientCodecConfigurer -> clientCodecConfigurer.defaultCodecs().maxInMemorySize(100 * 1024 * 1024)));
    }

    @Bean
    HttpFirewall httpFirewall() {
        DefaultHttpFirewall firewall = new DefaultHttpFirewall();
        firewall.setAllowUrlEncodedSlash(true);
        return firewall;
    }

//    @Bean
//    public Firestore db() throws IOException{
//        InputStream serviceAccount = getClass().getResourceAsStream("/private/flightsystem-387809-firebase-adminsdk-yfc6r-a0682967bf.json");
//        GoogleCredentials credentials = GoogleCredentials.fromStream(serviceAccount);
//        System.out.println("Service Account: " + serviceAccount);
//        System.out.println("Credentials: " + credentials);
//        FirebaseOptions.Builder firebaseOptions = new FirebaseOptions.Builder();
//        firebaseOptions.setCredentials(credentials);
//        firebaseOptions.setProjectId("flightsystem-387809");
//        System.out.println("FirestoreOptions: " + firebaseOptions);
//        FirebaseApp.initializeApp(firebaseOptions.build());
//        return FirestoreClient.getFirestore();
//    }

}
